.. Template for release notes. TODO: fill in the blanks and remove comments.

==============
Release Notes
==============

1.0.0
-----

Release date: Oct 13, 2023

**New Features and Enhancements:**

* Initial repository.

